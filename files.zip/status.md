# NovaLearning Project Status Command

> **Trigger:** `/project:status`
> **Purpose:** Quick overview of current project state

## Status Dashboard

```bash
#!/bin/bash
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║           🦁 NovaLearning Project Status 🦁                  ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Git Status
echo "📊 GIT STATUS"
echo "─────────────────────────────────────────"
echo "Branch: $(git branch --show-current 2>/dev/null || echo 'N/A')"
echo "Last Commit: $(git log --oneline -1 2>/dev/null || echo 'N/A')"
echo "Uncommitted: $(git status --short 2>/dev/null | wc -l | tr -d ' ') files"
echo ""

# Sprint Progress
echo "🎯 SPRINT PROGRESS"
echo "─────────────────────────────────────────"
if [ -f "PROGRESS.md" ]; then
  grep -E "^- \[.\]" PROGRESS.md 2>/dev/null | head -10
else
  echo "  (PROGRESS.md not found)"
fi
echo ""

# Asset Status
echo "🖼️  ASSET STATUS"
echo "─────────────────────────────────────────"
SPRITES=$(find src/assets/sprites/animals -name "*.png" 2>/dev/null | wc -l | tr -d ' ')
AUDIO=$(find src/assets/audio -name "*.mp3" 2>/dev/null | wc -l | tr -d ' ')
echo "Sprite Sheets: $SPRITES / 6"
echo "Audio Files: $AUDIO / 18 (6 phonics + 6 animals + 6 feedback)"
echo ""

# Scene Status
echo "🎮 SCENE STATUS"
echo "─────────────────────────────────────────"
for scene in BootScene MenuScene GameScene RewardScene; do
  if [ -f "src/games/letter-recognition/scenes/${scene}.js" ]; then
    echo "  ✅ ${scene}.js"
  else
    echo "  ⬜ ${scene}.js (not created)"
  fi
done
echo ""

# Performance Check
echo "⚡ PERFORMANCE SNAPSHOT"
echo "─────────────────────────────────────────"
if [ -d "dist" ]; then
  echo "Bundle: $(du -sh dist/ 2>/dev/null | cut -f1)"
  echo "JS Size: $(find dist/ -name '*.js' -exec cat {} \; 2>/dev/null | wc -c | awk '{printf "%.1fKB", $1/1024}')"
else
  echo "  (No build yet - run 'npm run build')"
fi
echo ""

# Next Actions
echo "📋 RECOMMENDED NEXT ACTIONS"
echo "─────────────────────────────────────────"
echo "1. Check PROGRESS.md for current task"
echo "2. Run /project:verify before commits"
echo "3. Use /plan for complex changes"
echo ""
echo "═══════════════════════════════════════════════════════════════"
```

## Manual Execution

If the above script doesn't work, run these commands individually:

### Git Overview
```bash
git branch --show-current && \
git log --oneline -3 && \
git status --short
```

### Asset Count
```bash
echo "Sprites:" && ls src/assets/sprites/animals/*.png 2>/dev/null | wc -l && \
echo "Audio:" && ls src/assets/audio/**/*.mp3 2>/dev/null | wc -l
```

### Scene Check
```bash
ls -la src/games/letter-recognition/scenes/*.js 2>/dev/null
```

### Build Size
```bash
du -sh dist/ 2>/dev/null
```

## Integration with PROGRESS.md

The status command reads from PROGRESS.md to show:
- Current sprint tasks
- Blocked items
- Recently completed work

Keep PROGRESS.md updated for accurate status reports!
