#!/bin/bash

# NovaLearning Claude Code Automation Setup Script
# Run this from your project root directory

set -e

echo "🦁 NovaLearning Claude Code Automation Setup"
echo "=============================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if we're in a git repository
if [ ! -d ".git" ]; then
    echo -e "${YELLOW}⚠️  Not a git repository. Initializing...${NC}"
    git init
fi

# Create directory structure
echo "📁 Creating directory structure..."
mkdir -p .claude/agents
mkdir -p .claude/commands
mkdir -p .claude/hooks
mkdir -p scripts
mkdir -p n8n-workflows
mkdir -p src/games/letter-recognition
mkdir -p src/scenes
mkdir -p src/assets/sprites/animals
mkdir -p src/assets/audio/phonics
mkdir -p src/assets/audio/animals
mkdir -p src/assets/audio/feedback
mkdir -p src/components
mkdir -p src/utils
mkdir -p src/config

echo -e "${GREEN}✓ Directories created${NC}"

# Copy automation files
AUTOMATION_DIR="/home/claude/novalearning-automation"

if [ -d "$AUTOMATION_DIR" ]; then
    echo "📋 Copying automation configuration..."
    
    # Core files
    cp "$AUTOMATION_DIR/CLAUDE.md" ./CLAUDE.md 2>/dev/null || echo "  - CLAUDE.md not found, skipping"
    cp "$AUTOMATION_DIR/PROGRESS.md" ./PROGRESS.md 2>/dev/null || echo "  - PROGRESS.md not found, skipping"
    
    # Claude settings
    cp "$AUTOMATION_DIR/.claude/settings.json" ./.claude/settings.json 2>/dev/null || echo "  - settings.json not found, skipping"
    
    # Commands
    cp "$AUTOMATION_DIR/.claude/commands/verify.md" ./.claude/commands/verify.md 2>/dev/null || echo "  - verify.md not found, skipping"
    cp "$AUTOMATION_DIR/.claude/commands/status.md" ./.claude/commands/status.md 2>/dev/null || echo "  - status.md not found, skipping"
    
    # Agents
    cp "$AUTOMATION_DIR/.claude/agents/asset-validator.md" ./.claude/agents/asset-validator.md 2>/dev/null || echo "  - asset-validator.md not found, skipping"
    cp "$AUTOMATION_DIR/.claude/agents/phaser-expert.md" ./.claude/agents/phaser-expert.md 2>/dev/null || echo "  - phaser-expert.md not found, skipping"
    cp "$AUTOMATION_DIR/.claude/agents/blender-asset-generator.md" ./.claude/agents/blender-asset-generator.md 2>/dev/null || echo "  - blender-asset-generator.md not found, skipping"
    
    # N8N workflows
    cp "$AUTOMATION_DIR/n8n-workflows/"*.json ./n8n-workflows/ 2>/dev/null || echo "  - N8N workflows not found, skipping"
    
    echo -e "${GREEN}✓ Configuration files copied${NC}"
else
    echo -e "${RED}✗ Automation directory not found at $AUTOMATION_DIR${NC}"
    echo "  Please ensure the automation files are created first."
fi

# Create package.json if it doesn't exist
if [ ! -f "package.json" ]; then
    echo "📦 Creating package.json..."
    cat > package.json << 'EOF'
{
  "name": "novalearning-letter-recognition",
  "version": "0.1.0",
  "description": "NovaLearning Letter Recognition Game - Ubuntu Buddies MVP",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "eslint src --ext .js,.jsx",
    "lint:fix": "eslint src --ext .js,.jsx --fix",
    "test": "vitest",
    "test:unit": "vitest run",
    "test:coverage": "vitest run --coverage",
    "validate:assets": "node scripts/validate-assets.js",
    "analyze": "vite-bundle-visualizer"
  },
  "dependencies": {
    "phaser": "^3.88.0",
    "howler": "^2.2.4",
    "zustand": "^4.5.0",
    "idb": "^8.0.0"
  },
  "devDependencies": {
    "vite": "^5.4.0",
    "eslint": "^8.57.0",
    "prettier": "^3.3.0",
    "vitest": "^2.0.0",
    "@vitest/coverage-v8": "^2.0.0",
    "vite-plugin-pwa": "^0.20.0"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}
EOF
    echo -e "${GREEN}✓ package.json created${NC}"
fi

# Create vite.config.js if it doesn't exist
if [ ! -f "vite.config.js" ]; then
    echo "⚡ Creating vite.config.js..."
    cat > vite.config.js << 'EOF'
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    VitePWA({
      registerType: 'autoUpdate',
      workbox: {
        globPatterns: ['**/*.{js,css,html,png,mp3,ogg,json}'],
        maximumFileSizeToCacheInBytes: 5 * 1024 * 1024 // 5MB
      },
      manifest: {
        name: 'NovaLearning Letter Recognition',
        short_name: 'NovaLetters',
        description: 'Learn letters A-F with Ubuntu Buddies',
        theme_color: '#2D5016',
        background_color: '#F5F5DC',
        display: 'fullscreen',
        orientation: 'portrait',
        icons: [
          {
            src: '/icons/icon-192.png',
            sizes: '192x192',
            type: 'image/png'
          },
          {
            src: '/icons/icon-512.png',
            sizes: '512x512',
            type: 'image/png'
          }
        ]
      }
    })
  ],
  build: {
    target: 'es2020',
    minify: 'terser',
    rollupOptions: {
      output: {
        manualChunks: {
          phaser: ['phaser'],
          audio: ['howler']
        }
      }
    },
    chunkSizeWarningLimit: 500
  },
  server: {
    host: true,
    port: 3000
  }
});
EOF
    echo -e "${GREEN}✓ vite.config.js created${NC}"
fi

# Create .gitignore if it doesn't exist
if [ ! -f ".gitignore" ]; then
    echo "🙈 Creating .gitignore..."
    cat > .gitignore << 'EOF'
# Dependencies
node_modules/

# Build output
dist/

# IDE
.vscode/
.idea/

# OS
.DS_Store
Thumbs.db

# Env files
.env
.env.local
.env.*.local

# Logs
*.log
npm-debug.log*

# Test coverage
coverage/

# Temp files
*.tmp
*.temp
EOF
    echo -e "${GREEN}✓ .gitignore created${NC}"
fi

# Create asset validation script
echo "🔍 Creating asset validation script..."
mkdir -p scripts
cat > scripts/validate-assets.js << 'EOF'
#!/usr/bin/env node

/**
 * NovaLearning Asset Validator
 * Validates sprites and audio files against project specifications
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ASSETS_DIR = path.join(__dirname, '..', 'src', 'assets');

const SPRITE_SPECS = {
  maxSizeKB: 500,
  dimensions: { width: 512, height: 512 },
  format: 'png',
  characters: ['aardvark', 'baboon', 'cheetah', 'dung-beetle', 'elephant', 'flamingo']
};

const AUDIO_SPECS = {
  phonics: { maxSizeKB: 50, maxDurationSec: 3 },
  animals: { maxSizeKB: 100, maxDurationSec: 4 },
  feedback: { maxSizeKB: 30, maxDurationSec: 2 }
};

function validateSprites() {
  const spritesDir = path.join(ASSETS_DIR, 'sprites', 'animals');
  const results = [];
  
  if (!fs.existsSync(spritesDir)) {
    console.log('⚠️  Sprites directory not found');
    return results;
  }
  
  const files = fs.readdirSync(spritesDir).filter(f => f.endsWith('.png'));
  
  for (const file of files) {
    const filePath = path.join(spritesDir, file);
    const stats = fs.statSync(filePath);
    const sizeKB = stats.size / 1024;
    
    results.push({
      file,
      sizeKB: sizeKB.toFixed(2),
      sizeOK: sizeKB <= SPRITE_SPECS.maxSizeKB,
      status: sizeKB <= SPRITE_SPECS.maxSizeKB ? '✓' : '✗'
    });
  }
  
  return results;
}

function validateAudio() {
  const results = [];
  const audioTypes = ['phonics', 'animals', 'feedback'];
  
  for (const type of audioTypes) {
    const audioDir = path.join(ASSETS_DIR, 'audio', type);
    
    if (!fs.existsSync(audioDir)) {
      console.log(`⚠️  Audio directory not found: ${type}`);
      continue;
    }
    
    const files = fs.readdirSync(audioDir).filter(f => 
      f.endsWith('.mp3') || f.endsWith('.ogg')
    );
    
    for (const file of files) {
      const filePath = path.join(audioDir, file);
      const stats = fs.statSync(filePath);
      const sizeKB = stats.size / 1024;
      const maxSize = AUDIO_SPECS[type].maxSizeKB;
      
      results.push({
        type,
        file,
        sizeKB: sizeKB.toFixed(2),
        sizeOK: sizeKB <= maxSize,
        status: sizeKB <= maxSize ? '✓' : '✗'
      });
    }
  }
  
  return results;
}

function main() {
  console.log('\n🔍 NovaLearning Asset Validation\n');
  console.log('='.repeat(50));
  
  // Validate sprites
  console.log('\n📦 SPRITES (max 500KB each)\n');
  const sprites = validateSprites();
  if (sprites.length === 0) {
    console.log('   No sprites found yet');
  } else {
    for (const s of sprites) {
      console.log(`   ${s.status} ${s.file} (${s.sizeKB}KB)`);
    }
  }
  
  // Validate audio
  console.log('\n🔊 AUDIO\n');
  const audio = validateAudio();
  if (audio.length === 0) {
    console.log('   No audio files found yet');
  } else {
    for (const a of audio) {
      console.log(`   ${a.status} [${a.type}] ${a.file} (${a.sizeKB}KB)`);
    }
  }
  
  // Summary
  console.log('\n' + '='.repeat(50));
  const spritesFailed = sprites.filter(s => !s.sizeOK).length;
  const audioFailed = audio.filter(a => !a.sizeOK).length;
  
  if (spritesFailed === 0 && audioFailed === 0) {
    console.log('✅ All assets validated successfully!\n');
    process.exit(0);
  } else {
    console.log(`❌ Validation failed: ${spritesFailed} sprites, ${audioFailed} audio files exceed limits\n`);
    process.exit(1);
  }
}

main();
EOF
chmod +x scripts/validate-assets.js
echo -e "${GREEN}✓ Asset validation script created${NC}"

# Create index.html
if [ ! -f "index.html" ]; then
    echo "📄 Creating index.html..."
    cat > index.html << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#2D5016">
    <meta name="description" content="Learn letters A-F with Ubuntu Buddies - NovaLearning">
    <title>NovaLearning Letter Recognition</title>
    <link rel="manifest" href="/manifest.webmanifest">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            background: #F5F5DC; 
            overflow: hidden;
            touch-action: none;
        }
        #game-container {
            width: 100vw;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #loading {
            font-family: 'Comic Sans MS', cursive;
            font-size: 24px;
            color: #2D5016;
            text-align: center;
        }
        .loading-dots::after {
            content: '';
            animation: dots 1.5s steps(4, end) infinite;
        }
        @keyframes dots {
            0%, 20% { content: ''; }
            40% { content: '.'; }
            60% { content: '..'; }
            80%, 100% { content: '...'; }
        }
    </style>
</head>
<body>
    <div id="game-container">
        <div id="loading">
            <p>🦁 Loading Ubuntu Buddies<span class="loading-dots"></span></p>
        </div>
    </div>
    <script type="module" src="/src/main.js"></script>
</body>
</html>
EOF
    echo -e "${GREEN}✓ index.html created${NC}"
fi

# Create main.js entry point
if [ ! -f "src/main.js" ]; then
    echo "🎮 Creating main.js entry point..."
    cat > src/main.js << 'EOF'
/**
 * NovaLearning Letter Recognition Game
 * Main entry point
 */

import Phaser from 'phaser';
// Import scenes (uncomment as they're created)
// import BootScene from './scenes/BootScene';
// import MenuScene from './scenes/MenuScene';
// import GameScene from './scenes/GameScene';
// import RewardScene from './scenes/RewardScene';

const config = {
  type: Phaser.AUTO,
  parent: 'game-container',
  width: 720,
  height: 1280,
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
  },
  backgroundColor: '#F5F5DC',
  physics: {
    default: 'arcade',
    arcade: {
      gravity: { y: 0 },
      debug: false
    }
  },
  scene: [
    // BootScene,
    // MenuScene, 
    // GameScene,
    // RewardScene
  ],
  render: {
    pixelArt: false,
    antialias: true,
  },
  input: {
    activePointers: 1
  }
};

// Hide loading message
const loading = document.getElementById('loading');
if (loading) {
  loading.style.display = 'none';
}

// Initialize game
const game = new Phaser.Game(config);

// PWA registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(reg => console.log('SW registered:', reg.scope))
      .catch(err => console.log('SW registration failed:', err));
  });
}

export default game;
EOF
    echo -e "${GREEN}✓ main.js created${NC}"
fi

echo ""
echo "=============================================="
echo -e "${GREEN}✅ NovaLearning automation setup complete!${NC}"
echo ""
echo "📋 Next steps:"
echo "   1. cd $(pwd)"
echo "   2. npm install"
echo "   3. claude  # Start Claude Code"
echo "   4. First prompt: \"ultrathink: Read CLAUDE.md and create implementation plan\""
echo ""
echo "📁 Files created:"
echo "   - CLAUDE.md (master context)"
echo "   - PROGRESS.md (sprint tracker)"
echo "   - .claude/settings.json (Claude Code config)"
echo "   - .claude/commands/ (verify, status)"
echo "   - .claude/agents/ (asset-validator, phaser-expert, blender-generator)"
echo "   - n8n-workflows/ (automation workflows)"
echo "   - scripts/validate-assets.js"
echo ""
echo "🦁 Happy building with Ubuntu Buddies!"
