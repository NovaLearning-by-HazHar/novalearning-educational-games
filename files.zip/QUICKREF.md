# 🦁 NovaLearning Quick Reference Card

## Daily Workflow (Boris Cherny Method)

```bash
# 1. Start session
claude

# 2. Plan with extended thinking
/plan "Implement [feature]"

# 3. Iterate until solid
# (discuss, refine, get confirmation)

# 4. Execute in one shot
/accept-all

# 5. Verify (auto-triggered, or manual)
/project:verify

# 6. Commit and move on
git add . && git commit -m "feat: [description]"
```

---

## Thinking Levels

| Task | Command | Cost |
|------|---------|------|
| Simple fix | `think:` | ~$0.06 |
| Scene implementation | `think hard:` | ~$0.15 |
| Architecture/planning | `ultrathink:` | ~$0.48 |

---

## Key Commands

| Command | Action |
|---------|--------|
| `/project:verify` | Run all verification checks |
| `/project:status` | Show progress dashboard |
| `/tasks` | List background tasks |
| `/teleport <id>` | Pull results from task |
| `/compact` | Compress context |

---

## Background Tasks (5x faster)

```bash
# Start async task
& Generate all 6 Ubuntu Buddy sprite sheets

# Check progress
/tasks

# Get results when done
/teleport <task-id>
```

---

## Parallel Development (Git Worktrees)

```bash
# Create feature branch in separate directory
nova-feature() {
  git worktree add "../novalearning-$1" -b "feature/nova-$1"
  cd "../novalearning-$1"
  npm install
  claude
}

# Usage
nova-feature asset-generation  # Terminal 1
nova-feature phaser-scenes     # Terminal 2
nova-feature workbook-pages    # Terminal 3
```

---

## Performance Budgets (NON-NEGOTIABLE)

| Metric | Target | Auto-Fail |
|--------|--------|-----------|
| Initial Load | < 3s | > 5s |
| FPS (Galaxy A03) | ≥ 24 | < 20 |
| JS Bundle | < 250KB | > 400KB |
| Per Sprite | < 500KB | > 1MB |
| Total Assets | < 50MB | > 75MB |

---

## Ubuntu Buddies Quick Reference

| Letter | Character | Color | Ubuntu Value |
|--------|-----------|-------|--------------|
| A | Ayo (Aardvark) | #E85D04 | Achievement |
| B | Buhle (Baboon) | #4CC9F0 | Bravery |
| C | Cindy (Cheetah) | #F4A261 | Champions |
| D | Dumisani (Dung Beetle) | #8D6748 | Determination |
| E | Elethu (Elephant) | #52B788 | Empathy |
| F | Fezile (Flamingo) | #FF6B9D | Family |

---

## File Structure

```
src/
├── games/letter-recognition/
│   └── config.js
├── scenes/
│   ├── BootScene.js
│   ├── MenuScene.js
│   ├── GameScene.js
│   └── RewardScene.js
├── assets/
│   ├── sprites/animals/
│   └── audio/{phonics,animals,feedback}/
├── components/
├── utils/
└── main.js
```

---

## Verification Loop

```
implement → /project:verify → fix issues → repeat until ✅
```

**All checks must pass before commit:**
- ✅ Build succeeds
- ✅ Bundle < 250KB
- ✅ No lint errors
- ✅ Tests pass
- ✅ Assets validated
- ✅ < 7 files changed

---

## Emergency Commands

```bash
# Reset to last good commit
git reset --hard HEAD~1

# Clear node_modules and rebuild
rm -rf node_modules && npm install

# Check bundle size
npm run build && du -sh dist/

# Validate all assets
npm run validate:assets
```

---

## N8N Webhook URLs

| Endpoint | Purpose |
|----------|---------|
| `/novalearning/generate-assets` | Trigger Blender MCP |
| `/novalearning/deploy` | Manual deploy |

---

**Remember:** CLAUDE.md has ALL context. Read it first every session! 🦁
