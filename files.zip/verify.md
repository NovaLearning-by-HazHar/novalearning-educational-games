# NovaLearning Verification Checklist

> **Auto-triggered after:** Write, Edit, npm run build
> **Manual trigger:** `/project:verify`

## Verification Steps

Run this complete checklist after each significant change:

### 1. 🔨 Build Check
```bash
npm run build
```
**Pass Criteria:** Exit code 0, no errors
**Auto-fail:** Any compilation error

### 2. 📦 Bundle Size Check
```bash
echo "=== Bundle Size Analysis ===" && \
du -sh dist/ 2>/dev/null && \
echo "" && \
echo "JS Bundle:" && \
find dist/ -name "*.js" -exec du -sh {} \; 2>/dev/null | head -5 && \
echo "" && \
echo "Target: <250KB gzipped"
```
**Pass Criteria:** Total JS < 250KB gzipped
**Auto-fail:** > 400KB

### 3. 🖼️ Asset Size Check
```bash
echo "=== Asset Analysis ===" && \
echo "" && \
echo "Sprite Sheets:" && \
ls -lh src/assets/sprites/animals/ 2>/dev/null || echo "  (No sprites yet)" && \
echo "" && \
echo "Audio Files:" && \
ls -lh src/assets/audio/**/*.mp3 2>/dev/null || echo "  (No audio yet)" && \
echo "" && \
echo "Target: Each sprite <500KB, Each audio <100KB"
```
**Pass Criteria:** 
- Each sprite sheet < 500KB
- Each audio file < 100KB
- Total assets < 50MB
**Auto-fail:** Any sprite > 1MB

### 4. 📝 Lint Check
```bash
npm run lint 2>&1 | tail -20
```
**Pass Criteria:** No errors (warnings OK)
**Auto-fail:** Any lint error

### 5. 🧪 Test Check
```bash
npm run test:unit -- --passWithNoTests 2>&1 | tail -10
```
**Pass Criteria:** All tests pass
**Auto-fail:** Any test failure

### 6. 📊 Git Status Check
```bash
echo "=== Git Status ===" && \
git status --short && \
echo "" && \
echo "Files changed:" && \
git diff --stat --cached 2>/dev/null || git diff --stat 2>/dev/null && \
echo "" && \
CHANGED=$(git diff --stat --cached 2>/dev/null | grep -c "file" || git diff --stat 2>/dev/null | grep -c "file" || echo "0") && \
echo "Total files changed: $CHANGED" && \
if [ "$CHANGED" -gt 7 ]; then echo "⚠️  WARNING: >7 files changed. Consider smaller commits."; fi
```
**Pass Criteria:** ≤7 files changed per commit
**Warning:** 8-15 files changed
**Auto-fail:** >15 files changed (split the PR)

### 7. 🎯 Performance Budget Check
```bash
echo "=== Performance Budgets ===" && \
echo "" && \
echo "Budget Limits:" && \
echo "  • Initial load: <3s (target 2s)" && \
echo "  • Min FPS: 24fps (target 30fps)" && \
echo "  • JS bundle: <250KB (target 150KB)" && \
echo "  • Total assets: <50MB (target 40MB)" && \
echo "  • Per sprite: <500KB (target 200KB)" && \
echo "" && \
echo "Note: FPS testing requires device/emulator"
```
**Pass Criteria:** All budgets met
**Auto-fail:** Any critical budget exceeded

### 8. 🌍 Cultural Integration Check
```bash
echo "=== Cultural Integration ===" && \
echo "" && \
echo "Checking for Ubuntu messages..." && \
grep -r "Ubuntu" src/ 2>/dev/null | head -5 || echo "  ⚠️  No Ubuntu references found" && \
echo "" && \
echo "Checking for SA animals..." && \
grep -rE "(Aardvark|Baboon|Cheetah|Dung.*Beetle|Elephant|Flamingo)" src/ 2>/dev/null | head -5 || echo "  ⚠️  No SA animal references found" && \
echo "" && \
echo "Note: Manual review required for cultural accuracy"
```
**Pass Criteria:** Ubuntu messages present in reward system
**Warning:** Missing cultural elements

## Summary Report Template

```
╔══════════════════════════════════════════════════════════════╗
║                  VERIFICATION REPORT                          ║
╠══════════════════════════════════════════════════════════════╣
║  Build:           ✅ PASS / ❌ FAIL                           ║
║  Bundle Size:     ✅ PASS / ❌ FAIL / ⚠️  WARNING             ║
║  Assets:          ✅ PASS / ❌ FAIL / ⚠️  WARNING             ║
║  Lint:            ✅ PASS / ❌ FAIL                           ║
║  Tests:           ✅ PASS / ❌ FAIL / ⏭️  SKIPPED             ║
║  Git Status:      ✅ PASS / ⚠️  WARNING                       ║
║  Performance:     ✅ PASS / ⚠️  NEEDS DEVICE TEST             ║
║  Cultural:        ✅ PASS / ⚠️  NEEDS REVIEW                  ║
╠══════════════════════════════════════════════════════════════╣
║  Overall:         ✅ READY TO COMMIT / ❌ FIX REQUIRED        ║
╚══════════════════════════════════════════════════════════════╝
```

## Quick Fix Commands

```bash
# Fix lint errors
npm run lint --fix

# Rebuild clean
rm -rf dist/ && npm run build

# Clear asset cache
rm -rf node_modules/.cache/

# Reset to last commit
git checkout -- .

# Stash changes
git stash save "WIP: before verification fix"
```

## When Verification Fails

1. **Build Failure:** Check error message, fix syntax/import issues
2. **Bundle Too Large:** Check for unnecessary imports, use code splitting
3. **Asset Too Large:** Compress images, reduce audio bitrate
4. **Lint Errors:** Run `npm run lint --fix`
5. **Test Failures:** Run specific test to debug: `npm test -- --grep "test name"`
6. **Too Many Files:** Break into smaller, focused commits

---

**Remember:** Never commit if verification fails. Fix issues first.
